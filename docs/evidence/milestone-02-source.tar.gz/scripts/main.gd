extends Node3D
## Composition root. Systems are wired by references and signals here.
const Verifier = preload("res://tests/traversal_verifier.gd")
const CombatVerifier = preload("res://tests/combat_verifier.gd")
var combat: PlayerCombat
var enemies: Array[EnemyActor] = []
var region: CoastalRegion
var player: PlayerController
var orbit: OrbitCamera
var interaction: InteractionController
var hud: GameHUD
var sites: Array[SurveySite] = []
var paused: bool = true
var started: bool = false
var verification_running: bool = false

func _ready() -> void:
	InputBindings.install()
	region = CoastalRegion.new()
	region.name = "CoastalRegion"
	add_child(region)
	player = PlayerController.new()
	player.name = "Player"
	add_child(player)
	player.spawn_position = Vector3(0, CoastalRegion.height_at(0, 12) + 0.12, 12)
	player.position = player.spawn_position
	orbit = OrbitCamera.new()
	orbit.name = "OrbitCamera"
	orbit.follow_target = player
	add_child(orbit)
	player.orbit = orbit
	orbit.snap()
	combat = PlayerCombat.new()
	combat.actor = player
	combat.orbit = orbit
	add_child(combat)
	_spawn_camp()
	_add_site("village", "Village noticeboard", "Port Solis: a starting point for bigger journeys.", Vector2(0, -2))
	_add_site("farm", "Olive farm", "The terraces will supply future delivery routes.", Vector2(-48, -57))
	_add_site("lookout", "Coastal lookout", "A flight route waits beyond the limestone arch.", Vector2(48, -91))
	interaction = InteractionController.new()
	interaction.actor = player
	interaction.sites = sites
	add_child(interaction)
	hud = GameHUD.new()
	hud.combat = combat
	hud.player = player
	hud.sites = sites
	add_child(hud)
	hud.start_requested.connect(_begin)
	hud.map_requested.connect(_toggle_map)
	hud.verify_requested.connect(run_verifier)
	hud.combat_verify_requested.connect(run_combat_verifier)
	interaction.prompt_changed.connect(hud.show_prompt)
	interaction.interacted.connect(func(site: SurveySite):
		player.stamina = player.config.stamina_max
		player.spawn_position = site.global_position + Vector3(0, 0.2, 1.5)
		hud.notify(site.description)
	)
	player.recovered.connect(func(): hud.notify("Returned to your last survey station."))
	hud.update_route()
	_set_paused(true)
	print("RSB_READY | Godot ", Engine.get_version_info().string, " | region=320m | terrain_tiles=100")
	var should_verify := "--verify" in OS.get_cmdline_user_args()
	if OS.has_feature("web"):
		should_verify = str(JavaScriptBridge.eval("window.location.search", true)).contains("verify=1")
	var combat_verify := "--verify-combat" in OS.get_cmdline_user_args()
	if OS.has_feature("web"):
		combat_verify = str(JavaScriptBridge.eval("window.location.search", true)).contains("verify=combat")
	if combat_verify:
		run_combat_verifier.call_deferred()
	elif should_verify:
		run_verifier.call_deferred()

func _add_site(id: String, title: String, description: String, at: Vector2) -> void:
	var site := SurveySite.new()
	site.site_id = id
	site.title = title
	site.description = description
	site.position = Vector3(at.x, CoastalRegion.height_at(at.x, at.y) + 0.08, at.y)
	add_child(site)
	sites.append(site)
	site.visited.connect(func(_site: SurveySite):
		hud.update_route()
		if hud.route_complete:
			hud.notify("First mile complete. All three stations surveyed.")
	)

func _begin() -> void:
	started = true
	hud.game_active = true
	hud.map_panel.visible = false
	_set_paused(false)
	combat.block_until_released = true
	# Embedded Chromium can reject pointer lock. Web uses drag / keyboard look.
	_capture_mouse()

func _capture_mouse() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if OS.has_feature("web") else Input.MOUSE_MODE_CAPTURED

func _set_paused(value: bool) -> void:
	paused = value
	player.set_controls(not value)
	player.set_physics_process(not value)
	orbit.input_enabled = not value
	orbit.drag_look = false
	interaction.enabled = not value
	combat.set_enabled(not value)
	for enemy in enemies:
		if is_instance_valid(enemy):
			enemy.set_simulation(not value)
	hud.show_pause(value)
	if value:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _toggle_map() -> void:
	if not started or verification_running:
		return
	var opening := not hud.map_panel.visible
	_set_paused(opening)
	hud.menu.visible = false
	hud.map_panel.visible = opening
	print("RSB_UI | map_open=", opening)
	if not opening:
		_capture_mouse()

func _input(event: InputEvent) -> void:
	# Global shortcuts must run before GUI focus can consume key events.
	if event.is_echo():
		return
	if verification_running:
		return
	if event.is_action_pressed("pause_game") and started:
		hud.map_panel.visible = false
		_set_paused(not paused)
		if not paused:
			_capture_mouse()
	elif event.is_action_pressed("map"):
		_toggle_map()
	elif event.is_action_pressed("verify"):
		run_verifier()

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT and started and not verification_running and is_instance_valid(hud):
		_set_paused(true)

func run_verifier() -> void:
	if verification_running:
		return
	verification_running = true
	started = true
	hud.game_active = true
	hud.map_panel.visible = false
	_set_paused(false)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	var verifier := Verifier.new()
	add_child(verifier)
	await verifier.run(self)
	verification_running = false
	verifier.queue_free()

func _spawn_camp() -> void:
	for info in [[Vector2(-62, 14), "Raider"], [Vector2(-73, -2), "Cinder beast"], [Vector2(-79, 7), "Raider"]]:
		var enemy := EnemyActor.new()
		enemy.kind = info[1]
		enemy.target = player
		enemy.position = Vector3(info[0].x, CoastalRegion.height_at(info[0].x, info[0].y) + 0.1, info[0].y)
		enemy.home = enemy.position
		add_child(enemy)
		enemies.append(enemy)
	var sign_at := Vector3(-34, CoastalRegion.height_at(-34, 12), 12)
	BlockoutKit.box(region, sign_at + Vector3.UP, Vector3(0.15, 2, 0.15), Color("765943"))
	BlockoutKit.box(region, sign_at + Vector3.UP * 1.7, Vector3(3.8, 0.8, 0.2), Color("753f30"))
	BlockoutKit.label(region, "DANGER  <  RAIDER CAMP", sign_at + Vector3(0, 1.7, 0.13), 23)

func run_combat_verifier() -> void:
	if verification_running:
		return
	verification_running = true
	started = true
	hud.game_active = true
	_set_paused(false)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	var verifier := CombatVerifier.new()
	add_child(verifier)
	await verifier.run(self)
	verification_running = false
	verifier.queue_free()
