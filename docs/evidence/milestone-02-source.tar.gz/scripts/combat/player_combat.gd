class_name PlayerCombat
extends Node3D
signal changed
signal enemy_defeated
var actor: PlayerController
var orbit: OrbitCamera
var config := WeaponConfig.new()
var health: HealthComponent
var enabled: bool = false
var weapon: String = "WRENCH"
var state: String = "READY"
var ammunition: int = 5
var reserve: int = 40
var aiming: bool = false
var target: EnemyActor
var clock: float = 0
var shot_cooldown: float = 0
var combo: int = 0
var combo_window: float = 0
var heavy: bool = false
var swing_targets: Dictionary = {}
var swing_count: int = 0
var shot_count: int = 0
var death_clock: float = 0
var wrench: Node3D
var rifle: Node3D
var tracer: MeshInstance3D
var tracer_time: float = 0
var flash: MeshInstance3D
var target_marker: Label3D
var last_hit: String = ""
var block_until_released: bool = false

func _ready() -> void:
	health = HealthComponent.new()
	health.faction = &"player"
	actor.add_child(health)
	health.died.connect(func(): death_clock = 2.0; cancel(); actor.set_controls(false))
	actor.recovered.connect(func(): health.restore(); cancel(); target = null)
	actor.dodged.connect(cancel)
	_build_weapons()

func _build_weapons() -> void:
	wrench = Node3D.new()
	actor.visual.right_arm.add_child(wrench)
	wrench.position = Vector3(0, -0.5, -0.12)
	BlockoutKit.box(wrench, Vector3(0, 0, -0.34), Vector3(0.10, 0.09, 0.64), Color("919c94"))
	for x in [-0.12, 0.12]:
		BlockoutKit.box(wrench, Vector3(x, 0, -0.7), Vector3(0.1, 0.12, 0.28), Color("b9c1b3"))
	BlockoutKit.box(wrench, Vector3(0, 0, -0.58), Vector3(0.29, 0.12, 0.14), Color("b9c1b3"))
	rifle = Node3D.new()
	actor.visual.torso.add_child(rifle)
	rifle.position = Vector3(0.24, 0.2, -0.42)
	BlockoutKit.box(rifle, Vector3(0, 0, -0.28), Vector3(0.12, 0.19, 0.9), Color("835837"))
	BlockoutKit.box(rifle, Vector3(0, 0.08, -0.8), Vector3(0.07, 0.08, 0.9), Color("414d4e"))
	flash = BlockoutKit.sphere(rifle, Vector3(0, 0.08, -1.3), Vector3(0.20, 0.20, 0.4), Color("ffc564"))
	flash.visible = false
	rifle.visible = false
	target_marker = BlockoutKit.label(self, "[   ]", Vector3.ZERO, 56)
	target_marker.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	target_marker.visible = false
	var line := BoxMesh.new()
	line.size = Vector3(0.025, 0.025, 1)
	tracer = BlockoutKit.mesh(self, line, Vector3.ZERO, Color("ffdd8a"))
	tracer.visible = false

func can_act() -> bool:
	return enabled and actor.input_enabled and health.current > 0 and actor.dodge_remaining <= 0

func cancel() -> void:
	if is_instance_valid(health):
		health.invulnerable = false
	state = "READY"
	clock = 0
	aiming = false
	swing_targets.clear()
	actor.speed_multiplier = 1.0

func set_enabled(value: bool) -> void:
	enabled = value
	if not value:
		cancel()

func equip(next: String) -> void:
	if not can_act() or state != "READY":
		return
	weapon = next
	wrench.visible = weapon == "WRENCH"
	rifle.visible = weapon == "RIFLE"
	combo = 0

func start_melee(is_heavy: bool = false) -> bool:
	if not can_act() or weapon != "WRENCH" or state != "READY" or not actor.is_on_floor():
		return false
	if not actor.spend_stamina(config.heavy_cost if is_heavy else config.light_cost):
		return false
	heavy = is_heavy
	combo = (combo % 3) + 1 if combo_window > 0 else 1
	combo_window = 1.4
	clock = 0
	state = "WINDUP"
	swing_targets.clear()
	swing_count += 1
	return true

func toggle_lock() -> void:
	if not can_act():
		return
	if is_instance_valid(target):
		target = null
		return
	var best := INF
	for enemy in get_tree().get_nodes_in_group("hostiles"):
		if not enemy is EnemyActor or enemy.health.current <= 0:
			continue
		var distance: float = enemy.position.distance_to(actor.position)
		if distance < 24 and distance < best and _clear_to(enemy):
			target = enemy
			best = distance

func _clear_to(enemy: EnemyActor) -> bool:
	return DamageSystem.clear_line(actor.get_world_3d(), actor.position + Vector3.UP * 1.2, enemy.position + Vector3.UP)

func _melee_hit() -> void:
	var forward := Vector3.FORWARD.rotated(Vector3.UP, actor.visual.rotation.y)
	for enemy in get_tree().get_nodes_in_group("hostiles"):
		if not enemy is EnemyActor or enemy.health.current <= 0 or swing_targets.has(enemy.get_instance_id()):
			continue
		var difference: Vector3 = enemy.position - actor.position
		var flat := Vector3(difference.x, 0, difference.z)
		if flat.length() <= config.melee_range and absf(difference.y) < 1.6 and forward.dot(flat.normalized()) > 0.25 and _clear_to(enemy):
			swing_targets[enemy.get_instance_id()] = true
			if DamageSystem.apply(enemy, config.heavy_damage if heavy else config.light_damage + (combo - 1) * 3, &"player"):
				last_hit = "Wrench hit · %s" % enemy.kind
				if enemy.health.current <= 0:
					enemy_defeated.emit()

func reload_weapon() -> bool:
	if not can_act() or weapon != "RIFLE" or state != "READY" or ammunition >= config.magazine_size or reserve <= 0:
		return false
	state = "RELOAD"
	clock = 0
	return true

func fire() -> bool:
	if not can_act() or weapon != "RIFLE" or state != "READY" or shot_cooldown > 0 or ammunition <= 0:
		return false
	ammunition -= 1
	shot_count += 1
	shot_cooldown = config.shot_interval
	var from := orbit.camera.global_position
	var direction := -orbit.camera.global_basis.z
	var query := PhysicsRayQueryParameters3D.create(from, from + direction * 120, 5)
	var hit := actor.get_world_3d().direct_space_state.intersect_ray(query)
	var end: Vector3 = hit.position if not hit.is_empty() else from + direction * 120
	var muzzle := actor.position + Vector3.UP * 1.35
	# A second ray from the actor prevents shooting through nearby cover from camera clearance.
	var cover := actor.get_world_3d().direct_space_state.intersect_ray(PhysicsRayQueryParameters3D.create(muzzle, end, 1))
	if not cover.is_empty():
		end = cover.position
	elif not hit.is_empty() and DamageSystem.apply(hit.collider, config.rifle_damage, &"player"):
		last_hit = "Rifle hit"
		var victim := DamageSystem.health_of(hit.collider)
		if victim.current <= 0:
			enemy_defeated.emit()
	var length := muzzle.distance_to(end)
	if length > 0.05:
		tracer.global_position = (muzzle + end) * 0.5
		tracer.look_at(end)
		tracer.scale = Vector3(1, 1, length)
	tracer_time = 0.07
	tracer.visible = true
	flash.visible = true
	orbit.pitch = clampf(orbit.pitch + 0.024, -1.1, 0.35)
	return true

func _physics_process(delta: float) -> void:
	if not enabled:
		return
	if health.current <= 0:
		death_clock -= delta
		if death_clock <= 0:
			actor.recover()
			actor.set_controls(true)
		return
	health.invulnerable = actor.dodge_remaining > 0.14 and actor.dodge_remaining < 0.44
	shot_cooldown = maxf(0, shot_cooldown - delta)
	combo_window = maxf(0, combo_window - delta)
	tracer_time = maxf(0, tracer_time - delta)
	tracer.visible = tracer_time > 0
	flash.visible = tracer_time > 0
	if Input.is_action_just_pressed("equip_wrench"):
		equip("WRENCH")
	if Input.is_action_just_pressed("equip_rifle"):
		equip("RIFLE")
	if Input.is_action_just_pressed("lock_target"):
		toggle_lock()
	if Input.is_action_just_pressed("reload"):
		reload_weapon()
	aiming = can_act() and weapon == "RIFLE" and Input.is_action_pressed("aim")
	if block_until_released and not Input.is_action_pressed("attack"):
		block_until_released = false
	if Input.is_action_just_pressed("attack") and not block_until_released:
		if weapon == "WRENCH":
			start_melee(false)
		else:
			fire()
	if Input.is_action_just_pressed("heavy_attack"):
		start_melee(true)
	if is_instance_valid(target):
		if target.health.current <= 0 or actor.position.distance_to(target.position) > 30 or not _clear_to(target):
			target = null
	if is_instance_valid(target):
		var difference := target.position - actor.position
		orbit.yaw = lerp_angle(orbit.yaw, atan2(-difference.x, -difference.z), delta * 8)
		orbit.pitch = lerpf(orbit.pitch, clampf(atan2(difference.y - 0.55, Vector2(difference.x, difference.z).length()), -1.1, 0.35), delta * 7)
		actor.visual.rotation.y = orbit.yaw
	elif aiming:
		actor.visual.rotation.y = orbit.yaw
	target_marker.visible = is_instance_valid(target)
	if is_instance_valid(target):
		target_marker.global_position = target.global_position + Vector3.UP * 1.2
	orbit.camera.fov = lerpf(orbit.camera.fov, 48.0 if aiming else 64.0, delta * 10)
	actor.speed_multiplier = 0.45 if aiming else (0.35 if state in ["WINDUP", "ACTIVE"] else 1.0)
	clock += delta
	if state == "WINDUP" and clock > (0.38 if heavy else 0.15):
		state = "ACTIVE"
		clock = 0
	if state == "ACTIVE":
		_melee_hit()
		if clock > 0.15:
			state = "RECOVERY"
			clock = 0
	if state == "RECOVERY" and clock > (0.42 if heavy else 0.22):
		state = "READY"
	if state == "RELOAD" and clock >= config.reload_seconds:
		var amount := mini(config.magazine_size - ammunition, reserve)
		ammunition += amount
		reserve -= amount
		state = "READY"
	if weapon == "WRENCH" and state != "READY":
		actor.visual.right_arm.rotation.x = -1.4 if state == "WINDUP" else 0.7
		actor.visual.right_arm.rotation.z = -0.8 if state == "ACTIVE" else 0
	else:
		actor.visual.right_arm.rotation.z = 0
