class_name CombatBrain
extends Node
## Reusable decision component; EnemyActor owns presentation and locomotion.
var actor: CharacterBody3D
var target: PlayerController
var machine := StateMachine.new()
var decision_clock: float = 0
var enabled: bool = true
var strike_done: bool = false
var detection_range: float = 17.0
var attack_range: float = 2.15
var damage: float = 13.0

func _ready() -> void:
	machine.register(&"Idle", _idle)
	machine.register(&"Pursue", _pursue)
	machine.register(&"Attack", _attack)
	machine.register(&"Hit", _hit)
	machine.register(&"Return", _return_home)
	machine.register(&"Dead", func(_delta): actor.desired_velocity = Vector3.ZERO)
	machine.transitioned.connect(func(_old, next):
		strike_done = false
		actor.state_label.text = "%s · %s" % [actor.kind, next]
	)

func _physics_process(delta: float) -> void:
	if not enabled or not is_instance_valid(target):
		return
	decision_clock += delta
	var interval := 0.1 if actor.position.distance_to(target.position) < 80 else 1.0
	if decision_clock >= interval:
		var step := decision_clock
		decision_clock = 0
		machine.tick(step)

func _distance() -> float:
	return actor.global_position.distance_to(target.global_position)

func _sees() -> bool:
	var health := DamageSystem.health_of(target)
	return health != null and health.current > 0 and DamageSystem.clear_line(actor.get_world_3d(), actor.global_position + Vector3.UP, target.global_position + Vector3.UP)

func _idle(_delta: float) -> void:
	actor.desired_velocity = Vector3.ZERO
	if _distance() < detection_range and _sees():
		machine.change(&"Pursue")

func _pursue(_delta: float) -> void:
	if _distance() > 28 or actor.position.distance_to(actor.home) > 27 or not _sees():
		machine.change(&"Return")
		return
	if _distance() < attack_range:
		actor.desired_velocity = Vector3.ZERO
		machine.change(&"Attack")
		return
	actor.desired_velocity = (target.position - actor.position).normalized() * actor.move_speed
	actor.desired_velocity.y = 0

func _attack(_delta: float) -> void:
	actor.desired_velocity = Vector3.ZERO
	actor.face(target.position)
	if machine.elapsed >= 0.55 and not strike_done:
		strike_done = true
		if _distance() < attack_range + 0.25 and _sees():
			DamageSystem.apply(target, damage, &"hostile")
	if machine.elapsed >= 1.2:
		machine.change(&"Pursue")

func _hit(_delta: float) -> void:
	actor.desired_velocity = Vector3.ZERO
	if machine.elapsed > 0.3:
		machine.change(&"Pursue")

func _return_home(_delta: float) -> void:
	var difference: Vector3 = actor.home - actor.position
	actor.desired_velocity = difference.normalized() * actor.move_speed
	actor.desired_velocity.y = 0
	if difference.length() < 1:
		machine.change(&"Idle")

func react_to_hit() -> void:
	machine.change(&"Hit")

func die() -> void:
	machine.change(&"Dead")
	actor.desired_velocity = Vector3.ZERO
