class_name InputBindings
extends RefCounted

static func install() -> void:
	var bindings := {
		"move_forward": [KEY_W, KEY_UP], "move_back": [KEY_S, KEY_DOWN],
		"move_left": [KEY_A, KEY_LEFT], "move_right": [KEY_D, KEY_RIGHT],
		"sprint": [KEY_SHIFT], "jump": [KEY_SPACE], "dodge": [KEY_CTRL, KEY_Q],
		"interact": [KEY_E], "pause_game": [KEY_ESCAPE], "map": [KEY_M],
		"reset_player": [KEY_R], "look_left": [KEY_J], "look_right": [KEY_L],
		"look_up": [KEY_I], "look_down": [KEY_K], "verify": [KEY_F9]
	}
	for action: String in bindings:
		if InputMap.has_action(action):
			continue
		InputMap.add_action(action)
		for key: int in bindings[action]:
			var event := InputEventKey.new()
			event.physical_keycode = key
			InputMap.action_add_event(action, event)
