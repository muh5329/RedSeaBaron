class_name BikeVisual
extends Node3D
var front_wheel: Node3D
var rear_wheel: Node3D
var rider: PlayerVisual

func _ready() -> void:
	var red := Color("a84e3d")
	var steel := Color("596460")
	var brass := Color("b39358")
	for z in [-1.0, 1.0]:
		var wheel := Node3D.new()
		wheel.position = Vector3(0, 0.48, z)
		add_child(wheel)
		var tire := BlockoutKit.cylinder(wheel, Vector3.ZERO, 0.48, 0.22, Color("273435"), -1, 16)
		tire.rotation.z = PI / 2
		for x in [-0.12, 0.12]:
			var rim := BlockoutKit.cylinder(wheel, Vector3(x, 0, 0), 0.31, 0.035, steel, -1, 10)
			rim.rotation.z = PI / 2
			var hub := BlockoutKit.cylinder(wheel, Vector3(x * 1.2, 0, 0), 0.13, 0.04, brass)
			hub.rotation.z = PI / 2
		if z < 0:
			front_wheel = wheel
		else:
			rear_wheel = wheel
	BlockoutKit.box(self, Vector3(0, 0.76, 0), Vector3(0.46, 0.42, 1.3), steel)
	BlockoutKit.box(self, Vector3(0, 1.08, -0.33), Vector3(0.66, 0.42, 0.82), red)
	BlockoutKit.box(self, Vector3(0, 1.22, 0.44), Vector3(0.54, 0.18, 0.96), Color("4e493a"))
	for x in [-0.27, 0.27]:
		var fork := BlockoutKit.box(self, Vector3(x, 0.99, -0.89), Vector3(0.09, 1.0, 0.09), brass)
		fork.rotation.x = -0.22
		BlockoutKit.box(self, Vector3(x, 0.56, 0.37), Vector3(0.09, 0.1, 1.2), red)
	BlockoutKit.box(self, Vector3(0, 1.48, -0.86), Vector3(1.18, 0.09, 0.12), steel)
	var lamp := BlockoutKit.cylinder(self, Vector3(0, 1.27, -1.06), 0.23, 0.20, brass, -1, 12)
	lamp.rotation.x = PI / 2
	var glass := BlockoutKit.cylinder(self, Vector3(0, 1.27, -1.18), 0.18, 0.025, Color("edce90"), -1, 12)
	glass.rotation.x = PI / 2
	rider = PlayerVisual.new()
	rider.position = Vector3(0, 0.75, 0.3)
	add_child(rider)
	rider.left_leg.rotation.x = -1.05
	rider.right_leg.rotation.x = -1.05
	rider.left_arm.rotation.x = -1.05
	rider.right_arm.rotation.x = -1.05
	rider.visible = false

func animate_vehicle(delta: float, speed: float, steering: float) -> void:
	front_wheel.rotation.y = steering * 0.32
	front_wheel.rotate_x(-speed * delta / 0.48)
	rear_wheel.rotate_x(-speed * delta / 0.48)
	rotation.z = lerpf(rotation.z, -steering * clampf(absf(speed) / 30, 0, 0.3), delta * 7)
