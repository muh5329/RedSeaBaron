# Red Sea Baron

A Godot 4.7 action-RPG project. **Milestone 01: traversal foundations** is implemented in a 320 × 320 m coastal blockout. This is the first verified development milestone, not the complete requested RPG.

Walk the village, olive farm and coastal lookout. Stamp all three survey stations with **E**. Each station also becomes your recovery point. The supplied landscape images informed the limestone cliffs, cypress trees, warm plaster buildings, farm and coastal trail; geometry is procedural placeholder art.

## Play

Open `project.godot` in Godot 4.7 and press **F6** on `scenes/main.tscn`, or **F5** from the project.

```sh
/Applications/Godot.app/Contents/MacOS/Godot --path .
```

For the local Web build:

```sh
tools/serve.sh
```

Open <http://127.0.0.1:8067>. The server is local-only. It must keep running while you play. To rebuild, use the verification command below. Web needs WebGL 2; it uses the Compatibility renderer and a single-thread export with no CDN or external asset dependencies. Export configuration follows the [official Godot Web export documentation](https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_web.html).

## Controls

| Input | Action |
| --- | --- |
| WASD / arrows | Camera-relative movement |
| Shift | Sprint; consumes stamina |
| Space | Jump; consumes stamina |
| Q / Ctrl | Dodge; consumes stamina |
| Right mouse drag | Orbit camera |
| I / J / K / L | Camera pitch / yaw without a mouse |
| Mouse wheel | Camera distance, 3–9 m |
| E | Stamp / rest at a nearby survey station |
| M | Map; pauses movement |
| Esc | Pause / resume and controls |
| R | Recover at the last survey station |
| F9 / pause-menu button | Run the traversal verifier |

Native play also captures the mouse. Web deliberately uses right-drag and IJKL because the embedded browser rejected pointer lock. No pointer-lock permission is needed to play the Web build.

## Verification

```sh
tools/verify.sh
```

This imports the project, runs 21 native checks, validates the JSON results, and exports the Web build. It exits nonzero for failed assertions, parsing errors, runtime errors or export failures. Set `GODOT_BIN` to another installed Godot 4.7 executable when needed. The matching Web export templates must be installed.

Then start `tools/serve.sh` and open <http://127.0.0.1:8067/?verify=1>, or use F9 in the game. The browser drives the same production controllers using Godot input actions. Tests take approximately one minute; leave the controls idle. The JSON report is shown as visible page text after completion, alongside a result in the game HUD. Reload the normal URL to dismiss the verifier report.

The verifier includes grounding, walking, sprinting, stamina regeneration/exhaustion, diagonal normalization, rotated-camera movement, jumping/landing, dodge displacement, low-stamina rejection, sprint/dodge wall collision, camera retraction/restoration, pause/map gating, recovery, the entire three-station route, duplicate/distant interaction rejection and simultaneous jump/dodge spam.

Isolated checks reposition the player to establish fixtures. The integrated survey route physically walks between every station. The verifier restores survey flags, checkpoint, player position and traversal counters afterwards. Native runs invoked with `-- --verify` exit with the test result. Normal F9/Web runs remain playable.

Latest native report: `docs/evidence/native-report.json`. Browser results, console records and screenshots are in `docs/evidence/`.

## Implemented / deferred

**Implemented:** movement, sprint, jump buffering/coyote time, dodge motion, stamina, capsule terrain collision, collision-aware third-person camera, interaction range/line-of-sight, survey route/checkpoints, field map, pause/focus handling, native/Web verifier and procedural coastal region.

**Deferred to subsequent milestones:** lock-on targeting, wrench/rifle combat, health/damage, enemies, rideable motorcycle, flight transformation, cargo cart, worker state machines/jobs, inventories, economy, deliveries, saves, streaming and large-world traversal. The workshop and farm are scenery and survey destinations, not working vehicle or logistics systems.

The current terrain has **100 static tiles**, all resident. This establishes a replaceable terrain boundary but **does not demonstrate streaming or a 25 km × 25 km world**. Full final-art matching is also outside this milestone.

See `docs/GAUNTLET_PROGRESS.md` for rounds, rubric scores, failures and evidence; `docs/ARCHITECTURE.md` for the expansion plan. The original request is preserved in `docs/PROJECT_BRIEF.txt`.
