#!/bin/bash
# Native verification and a single-thread Godot Web debug export.
set -euo pipefail
cd "$(dirname "$0")/.."
GODOT_BIN="${GODOT_BIN:-/Applications/Godot.app/Contents/MacOS/Godot}"
mkdir -p docs/evidence builds/web
"$GODOT_BIN" --headless --editor --path . --import --quit > docs/evidence/import.log 2>&1
if rg -n 'SCRIPT ERROR|^ERROR:' docs/evidence/import.log; then exit 1; fi
"$GODOT_BIN" --headless --path . -- --verify > docs/evidence/native-verifier.log 2>&1
if rg -n 'SCRIPT ERROR|^ERROR:|RSB_TEST \| FAIL' docs/evidence/native-verifier.log; then exit 1; fi
python3 - <<'PY'
import json
r=json.load(open('docs/evidence/native-report.json'))
assert r['passed']==r['total'] and r['total']>=21
print(f"Native: {r['passed']}/{r['total']} tests passed in {r['elapsed_seconds']:.1f}s")
PY
"$GODOT_BIN" --headless --path . --export-debug Web builds/web/index.html > docs/evidence/web-export.log 2>&1
if rg -n 'SCRIPT ERROR|^ERROR:' docs/evidence/web-export.log; then exit 1; fi
printf '%s\n' 'Web export built. Serve with tools/serve.sh, then open http://127.0.0.1:8067/?verify=1'
